class User:
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account_balance = 0
    def make_deposit(self, amount):
        self.account_balance += amount
    def make_withdrawal(self, amount):
        self.account_balance -= amount
    def display_user_balance(self):
        print(f"Hello {self.name}. Your balance is: ${self.account_balance}")
    def transfer(self, other_user, amount):
        self.account_balance -= amount
        other_user.account_balance += amount

greg = User("Greg Smelly", "gsmelly@gmail.com")
gary = User("Gary Simp", "garySimper123@gmail.com")
numbathree = User("Numba Tree", "numbathreeisbiggerthanfour@email.com")

greg.make_deposit(100)
greg.make_deposit(100)
greg.make_deposit(100)
greg.make_withdrawal(50)
greg.display_user_balance()

gary.make_deposit(50)
gary.make_deposit(50)
gary.make_withdrawal(90)
gary.display_user_balance()

numbathree.make_deposit(10000)
numbathree.make_withdrawal(5000)
numbathree.make_withdrawal(5)
numbathree.make_withdrawal(132)
numbathree.display_user_balance()

greg.transfer(numbathree, 50)
greg.display_user_balance()
numbathree.display_user_balance()