




class User:
    def __init__(self, name, email_address, intBalance, accountName):
        self.name = name
        self.email = email_address
        
        self.account = Bank_account(intBalance, accountName)
        
        
        self.user_accounts = Bank_account.user_accounts
        def open_account(accountName):
            Bank_account.user_accounts.append(accountName)
        if len(self.user_accounts) > 0:
            open_account(accountName)
        self.user_accounts = Bank_account.user_accounts
        
    def make_deposit(self, amount, accountName):
        self.account.make_deposit(amount, accountName)
        return self
    
    def make_withdrawal(self, amount, accountName):
        self.account.make_withdrawal(amount, accountName)
        return self
    
    def transfer(self, other_user, amount, accountName):
        self.account -= amount
        other_user.account += amount
        return self
    
    def display_user_balance(self):
        print(f"Hello {self.name}. Your balance is: ${self.account.account_bal}")
        return 
    
    def display_user_accounts(self):
        print(self.user_accounts)
    

class User_accounts:
    pass

class Bank_account:
    all_accounts = []
    user_accounts = []
    def __init__(self, intBalance, accountName):
        if intBalance > 0: 
            self.account_bal = intBalance
        else:
            self.account_bal = 0
        self.account_name = accountName
        
        Bank_account.all_accounts.append(self)
    def make_deposit(self, amount, account_name):
        self.account_bal += amount
        return self
    def make_withdrawal(self, amount, account_name):
        self.account_bal -= amount
        return self
    def yield_interest(self):
        if self.account_bal > 0:
            self.account_bal += self.account_bal*0.1 
            return self
    @classmethod
    def all_bal(cls):
        sum = 0
        for accounts in cls.all_accounts:
            sum += accounts.account_bal
        print(f"Everyone's money combined is: {sum}")


greg = User(name="Greg Smelly",email_address="gsmelly@gmail.com", intBalance=300, accountName="account1")
greg 
greg.display_user_balance()
greg.display_user_accounts()



