from flask import Flask
# from flask-app.models import #model_name
DATABASE =  "dojo_survey"


app = Flask(__name__)
app.secret_key = "kekekekekek"
